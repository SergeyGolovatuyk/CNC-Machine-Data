﻿namespace GeissBarcodeTest
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.EventLog = new System.Windows.Forms.RichTextBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.ConnectionLinkLamp = new System.Windows.Forms.ToolStripStatusLabel();
            this.ConnectionStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.StatusIP_AddressLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.MainMenuStrip = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pLCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.connectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.disconnectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.connectionSettingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.databaseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.watchBarcodeRWTHistoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.watchMachineParametersHistoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BarcodeLabel = new System.Windows.Forms.Label();
            this.BarcodeR = new System.Windows.Forms.TextBox();
            this.Timer1 = new System.Windows.Forms.Timer(this.components);
            this.Timer2 = new System.Windows.Forms.Timer(this.components);
            this.RWT_1_Label = new System.Windows.Forms.Label();
            this.RWT_1_Output = new System.Windows.Forms.TextBox();
            this.BarcodeRwtTitle = new System.Windows.Forms.Label();
            this.RWT_2_Output = new System.Windows.Forms.TextBox();
            this.RWT_2_Label = new System.Windows.Forms.Label();
            this.RWT_3_Output = new System.Windows.Forms.TextBox();
            this.RWT_3_Label = new System.Windows.Forms.Label();
            this.RWT_4_Output = new System.Windows.Forms.TextBox();
            this.RWT_4_Label = new System.Windows.Forms.Label();
            this.RWT_8_Output = new System.Windows.Forms.TextBox();
            this.RWT_8_Label = new System.Windows.Forms.Label();
            this.RWT_7_Output = new System.Windows.Forms.TextBox();
            this.RWT_7_Label = new System.Windows.Forms.Label();
            this.RWT_6_Output = new System.Windows.Forms.TextBox();
            this.RWT_6_Label = new System.Windows.Forms.Label();
            this.RWT_5_Output = new System.Windows.Forms.TextBox();
            this.RWT_5_Label = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.RWT_16_Output = new System.Windows.Forms.TextBox();
            this.RWT_16_Label = new System.Windows.Forms.Label();
            this.RWT_15_Output = new System.Windows.Forms.TextBox();
            this.RWT_15_Label = new System.Windows.Forms.Label();
            this.RWT_14_Output = new System.Windows.Forms.TextBox();
            this.RWT_14_Label = new System.Windows.Forms.Label();
            this.RWT_13_Output = new System.Windows.Forms.TextBox();
            this.RWT_13_Label = new System.Windows.Forms.Label();
            this.RWT_12_Output = new System.Windows.Forms.TextBox();
            this.RWT_12_Label = new System.Windows.Forms.Label();
            this.RWT_11_Output = new System.Windows.Forms.TextBox();
            this.RWT_11_Label = new System.Windows.Forms.Label();
            this.RWT_10_Output = new System.Windows.Forms.TextBox();
            this.RWT_10_Label = new System.Windows.Forms.Label();
            this.RWT_9_Output = new System.Windows.Forms.TextBox();
            this.RWT_9_Label = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.statusStrip1.SuspendLayout();
            this.MainMenuStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // EventLog
            // 
            this.EventLog.Cursor = System.Windows.Forms.Cursors.No;
            this.EventLog.Location = new System.Drawing.Point(0, 558);
            this.EventLog.Name = "EventLog";
            this.EventLog.Size = new System.Drawing.Size(582, 96);
            this.EventLog.TabIndex = 9;
            this.EventLog.Text = "";
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.ConnectionLinkLamp,
            this.ConnectionStatus,
            this.StatusIP_AddressLabel});
            this.statusStrip1.Location = new System.Drawing.Point(0, 641);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(871, 29);
            this.statusStrip1.TabIndex = 10;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.toolStripStatusLabel1.BorderStyle = System.Windows.Forms.Border3DStyle.RaisedOuter;
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(135, 24);
            this.toolStripStatusLabel1.Text = "Connection Status:";
            // 
            // ConnectionLinkLamp
            // 
            this.ConnectionLinkLamp.AutoSize = false;
            this.ConnectionLinkLamp.BackColor = System.Drawing.SystemColors.Control;
            this.ConnectionLinkLamp.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.ConnectionLinkLamp.Name = "ConnectionLinkLamp";
            this.ConnectionLinkLamp.Size = new System.Drawing.Size(20, 24);
            // 
            // ConnectionStatus
            // 
            this.ConnectionStatus.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.ConnectionStatus.BorderStyle = System.Windows.Forms.Border3DStyle.RaisedOuter;
            this.ConnectionStatus.Name = "ConnectionStatus";
            this.ConnectionStatus.Size = new System.Drawing.Size(172, 24);
            this.ConnectionStatus.Text = "Provider PLC IP Address:";
            // 
            // StatusIP_AddressLabel
            // 
            this.StatusIP_AddressLabel.AutoSize = false;
            this.StatusIP_AddressLabel.Name = "StatusIP_AddressLabel";
            this.StatusIP_AddressLabel.Size = new System.Drawing.Size(100, 24);
            this.StatusIP_AddressLabel.Text = "0.0.0.0";
            // 
            // MainMenuStrip
            // 
            this.MainMenuStrip.BackColor = System.Drawing.Color.CornflowerBlue;
            this.MainMenuStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.MainMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.pLCToolStripMenuItem,
            this.databaseToolStripMenuItem});
            this.MainMenuStrip.Location = new System.Drawing.Point(0, 0);
            this.MainMenuStrip.Name = "MainMenuStrip";
            this.MainMenuStrip.Size = new System.Drawing.Size(871, 28);
            this.MainMenuStrip.TabIndex = 11;
            this.MainMenuStrip.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(44, 24);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(108, 26);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // pLCToolStripMenuItem
            // 
            this.pLCToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.connectToolStripMenuItem,
            this.disconnectToolStripMenuItem,
            this.connectionSettingsToolStripMenuItem});
            this.pLCToolStripMenuItem.Name = "pLCToolStripMenuItem";
            this.pLCToolStripMenuItem.Size = new System.Drawing.Size(45, 24);
            this.pLCToolStripMenuItem.Text = "PLC";
            // 
            // connectToolStripMenuItem
            // 
            this.connectToolStripMenuItem.Name = "connectToolStripMenuItem";
            this.connectToolStripMenuItem.Size = new System.Drawing.Size(216, 26);
            this.connectToolStripMenuItem.Text = "Connect";
            this.connectToolStripMenuItem.Click += new System.EventHandler(this.connectToolStripMenuItem_Click);
            // 
            // disconnectToolStripMenuItem
            // 
            this.disconnectToolStripMenuItem.Name = "disconnectToolStripMenuItem";
            this.disconnectToolStripMenuItem.Size = new System.Drawing.Size(216, 26);
            this.disconnectToolStripMenuItem.Text = "Disconnect";
            this.disconnectToolStripMenuItem.Click += new System.EventHandler(this.disconnectToolStripMenuItem_Click);
            // 
            // connectionSettingsToolStripMenuItem
            // 
            this.connectionSettingsToolStripMenuItem.Name = "connectionSettingsToolStripMenuItem";
            this.connectionSettingsToolStripMenuItem.Size = new System.Drawing.Size(216, 26);
            this.connectionSettingsToolStripMenuItem.Text = "Connection Settings";
            this.connectionSettingsToolStripMenuItem.Click += new System.EventHandler(this.connectionSettingsToolStripMenuItem_Click);
            // 
            // databaseToolStripMenuItem
            // 
            this.databaseToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.watchBarcodeRWTHistoryToolStripMenuItem,
            this.watchMachineParametersHistoryToolStripMenuItem});
            this.databaseToolStripMenuItem.Name = "databaseToolStripMenuItem";
            this.databaseToolStripMenuItem.Size = new System.Drawing.Size(84, 24);
            this.databaseToolStripMenuItem.Text = "Database";
            // 
            // watchBarcodeRWTHistoryToolStripMenuItem
            // 
            this.watchBarcodeRWTHistoryToolStripMenuItem.Name = "watchBarcodeRWTHistoryToolStripMenuItem";
            this.watchBarcodeRWTHistoryToolStripMenuItem.Size = new System.Drawing.Size(315, 26);
            this.watchBarcodeRWTHistoryToolStripMenuItem.Text = "Watch Barcode/RWT History";
            this.watchBarcodeRWTHistoryToolStripMenuItem.Click += new System.EventHandler(this.watchBarcodeRWTHistoryToolStripMenuItem_Click);
            // 
            // watchMachineParametersHistoryToolStripMenuItem
            // 
            this.watchMachineParametersHistoryToolStripMenuItem.Name = "watchMachineParametersHistoryToolStripMenuItem";
            this.watchMachineParametersHistoryToolStripMenuItem.Size = new System.Drawing.Size(315, 26);
            this.watchMachineParametersHistoryToolStripMenuItem.Text = "Watch Machine Parameters History";
            // 
            // BarcodeLabel
            // 
            this.BarcodeLabel.AutoSize = true;
            this.BarcodeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BarcodeLabel.Location = new System.Drawing.Point(34, 110);
            this.BarcodeLabel.Name = "BarcodeLabel";
            this.BarcodeLabel.Size = new System.Drawing.Size(82, 17);
            this.BarcodeLabel.TabIndex = 13;
            this.BarcodeLabel.Text = "BARCODE";
            // 
            // BarcodeR
            // 
            this.BarcodeR.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.BarcodeR.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BarcodeR.Location = new System.Drawing.Point(120, 107);
            this.BarcodeR.Name = "BarcodeR";
            this.BarcodeR.Size = new System.Drawing.Size(212, 22);
            this.BarcodeR.TabIndex = 12;
            // 
            // RWT_1_Label
            // 
            this.RWT_1_Label.BackColor = System.Drawing.Color.CornflowerBlue;
            this.RWT_1_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RWT_1_Label.Location = new System.Drawing.Point(28, 149);
            this.RWT_1_Label.Name = "RWT_1_Label";
            this.RWT_1_Label.Size = new System.Drawing.Size(62, 17);
            this.RWT_1_Label.TabIndex = 14;
            this.RWT_1_Label.Text = "RWT[1]";
            this.RWT_1_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // RWT_1_Output
            // 
            this.RWT_1_Output.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.RWT_1_Output.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RWT_1_Output.Location = new System.Drawing.Point(105, 148);
            this.RWT_1_Output.Name = "RWT_1_Output";
            this.RWT_1_Output.Size = new System.Drawing.Size(82, 24);
            this.RWT_1_Output.TabIndex = 15;
            // 
            // BarcodeRwtTitle
            // 
            this.BarcodeRwtTitle.BackColor = System.Drawing.Color.Yellow;
            this.BarcodeRwtTitle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.BarcodeRwtTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BarcodeRwtTitle.Location = new System.Drawing.Point(22, 41);
            this.BarcodeRwtTitle.Name = "BarcodeRwtTitle";
            this.BarcodeRwtTitle.Size = new System.Drawing.Size(364, 56);
            this.BarcodeRwtTitle.TabIndex = 16;
            this.BarcodeRwtTitle.Text = "Last Barcode Read and\r\nRemain Thickness Value";
            this.BarcodeRwtTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // RWT_2_Output
            // 
            this.RWT_2_Output.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.RWT_2_Output.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RWT_2_Output.Location = new System.Drawing.Point(105, 173);
            this.RWT_2_Output.Name = "RWT_2_Output";
            this.RWT_2_Output.Size = new System.Drawing.Size(82, 24);
            this.RWT_2_Output.TabIndex = 18;
            // 
            // RWT_2_Label
            // 
            this.RWT_2_Label.BackColor = System.Drawing.Color.CornflowerBlue;
            this.RWT_2_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RWT_2_Label.Location = new System.Drawing.Point(28, 174);
            this.RWT_2_Label.Name = "RWT_2_Label";
            this.RWT_2_Label.Size = new System.Drawing.Size(62, 17);
            this.RWT_2_Label.TabIndex = 17;
            this.RWT_2_Label.Text = "RWT[2]";
            this.RWT_2_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // RWT_3_Output
            // 
            this.RWT_3_Output.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.RWT_3_Output.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RWT_3_Output.Location = new System.Drawing.Point(105, 198);
            this.RWT_3_Output.Name = "RWT_3_Output";
            this.RWT_3_Output.Size = new System.Drawing.Size(82, 24);
            this.RWT_3_Output.TabIndex = 20;
            // 
            // RWT_3_Label
            // 
            this.RWT_3_Label.BackColor = System.Drawing.Color.CornflowerBlue;
            this.RWT_3_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RWT_3_Label.Location = new System.Drawing.Point(28, 198);
            this.RWT_3_Label.Name = "RWT_3_Label";
            this.RWT_3_Label.Size = new System.Drawing.Size(62, 17);
            this.RWT_3_Label.TabIndex = 19;
            this.RWT_3_Label.Text = "RWT[3]";
            this.RWT_3_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // RWT_4_Output
            // 
            this.RWT_4_Output.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.RWT_4_Output.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RWT_4_Output.Location = new System.Drawing.Point(105, 223);
            this.RWT_4_Output.Name = "RWT_4_Output";
            this.RWT_4_Output.Size = new System.Drawing.Size(82, 24);
            this.RWT_4_Output.TabIndex = 22;
            // 
            // RWT_4_Label
            // 
            this.RWT_4_Label.BackColor = System.Drawing.Color.CornflowerBlue;
            this.RWT_4_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RWT_4_Label.Location = new System.Drawing.Point(28, 223);
            this.RWT_4_Label.Name = "RWT_4_Label";
            this.RWT_4_Label.Size = new System.Drawing.Size(62, 17);
            this.RWT_4_Label.TabIndex = 21;
            this.RWT_4_Label.Text = "RWT[4]";
            this.RWT_4_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // RWT_8_Output
            // 
            this.RWT_8_Output.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.RWT_8_Output.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RWT_8_Output.Location = new System.Drawing.Point(105, 323);
            this.RWT_8_Output.Name = "RWT_8_Output";
            this.RWT_8_Output.Size = new System.Drawing.Size(82, 24);
            this.RWT_8_Output.TabIndex = 30;
            // 
            // RWT_8_Label
            // 
            this.RWT_8_Label.BackColor = System.Drawing.Color.CornflowerBlue;
            this.RWT_8_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RWT_8_Label.Location = new System.Drawing.Point(28, 324);
            this.RWT_8_Label.Name = "RWT_8_Label";
            this.RWT_8_Label.Size = new System.Drawing.Size(62, 17);
            this.RWT_8_Label.TabIndex = 29;
            this.RWT_8_Label.Text = "RWT[8]";
            this.RWT_8_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // RWT_7_Output
            // 
            this.RWT_7_Output.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.RWT_7_Output.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RWT_7_Output.Location = new System.Drawing.Point(105, 298);
            this.RWT_7_Output.Name = "RWT_7_Output";
            this.RWT_7_Output.Size = new System.Drawing.Size(82, 24);
            this.RWT_7_Output.TabIndex = 28;
            // 
            // RWT_7_Label
            // 
            this.RWT_7_Label.BackColor = System.Drawing.Color.CornflowerBlue;
            this.RWT_7_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RWT_7_Label.Location = new System.Drawing.Point(28, 299);
            this.RWT_7_Label.Name = "RWT_7_Label";
            this.RWT_7_Label.Size = new System.Drawing.Size(62, 17);
            this.RWT_7_Label.TabIndex = 27;
            this.RWT_7_Label.Text = "RWT[7]";
            this.RWT_7_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // RWT_6_Output
            // 
            this.RWT_6_Output.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.RWT_6_Output.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RWT_6_Output.Location = new System.Drawing.Point(105, 273);
            this.RWT_6_Output.Name = "RWT_6_Output";
            this.RWT_6_Output.Size = new System.Drawing.Size(82, 24);
            this.RWT_6_Output.TabIndex = 26;
            // 
            // RWT_6_Label
            // 
            this.RWT_6_Label.BackColor = System.Drawing.Color.CornflowerBlue;
            this.RWT_6_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RWT_6_Label.Location = new System.Drawing.Point(28, 275);
            this.RWT_6_Label.Name = "RWT_6_Label";
            this.RWT_6_Label.Size = new System.Drawing.Size(62, 17);
            this.RWT_6_Label.TabIndex = 25;
            this.RWT_6_Label.Text = "RWT[6]";
            this.RWT_6_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // RWT_5_Output
            // 
            this.RWT_5_Output.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.RWT_5_Output.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RWT_5_Output.Location = new System.Drawing.Point(105, 248);
            this.RWT_5_Output.Name = "RWT_5_Output";
            this.RWT_5_Output.Size = new System.Drawing.Size(82, 24);
            this.RWT_5_Output.TabIndex = 24;
            // 
            // RWT_5_Label
            // 
            this.RWT_5_Label.BackColor = System.Drawing.Color.CornflowerBlue;
            this.RWT_5_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RWT_5_Label.Location = new System.Drawing.Point(28, 249);
            this.RWT_5_Label.Name = "RWT_5_Label";
            this.RWT_5_Label.Size = new System.Drawing.Size(62, 17);
            this.RWT_5_Label.TabIndex = 23;
            this.RWT_5_Label.Text = "RWT[5]";
            this.RWT_5_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
            this.pictureBox1.Location = new System.Drawing.Point(715, 28);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(153, 80);
            this.pictureBox1.TabIndex = 31;
            this.pictureBox1.TabStop = false;
            // 
            // RWT_16_Output
            // 
            this.RWT_16_Output.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.RWT_16_Output.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RWT_16_Output.Location = new System.Drawing.Point(105, 523);
            this.RWT_16_Output.Name = "RWT_16_Output";
            this.RWT_16_Output.Size = new System.Drawing.Size(82, 24);
            this.RWT_16_Output.TabIndex = 47;
            // 
            // RWT_16_Label
            // 
            this.RWT_16_Label.BackColor = System.Drawing.Color.CornflowerBlue;
            this.RWT_16_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RWT_16_Label.Location = new System.Drawing.Point(28, 525);
            this.RWT_16_Label.Name = "RWT_16_Label";
            this.RWT_16_Label.Size = new System.Drawing.Size(71, 17);
            this.RWT_16_Label.TabIndex = 46;
            this.RWT_16_Label.Text = "RWT[16]";
            this.RWT_16_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // RWT_15_Output
            // 
            this.RWT_15_Output.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.RWT_15_Output.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RWT_15_Output.Location = new System.Drawing.Point(105, 498);
            this.RWT_15_Output.Name = "RWT_15_Output";
            this.RWT_15_Output.Size = new System.Drawing.Size(82, 24);
            this.RWT_15_Output.TabIndex = 45;
            // 
            // RWT_15_Label
            // 
            this.RWT_15_Label.BackColor = System.Drawing.Color.CornflowerBlue;
            this.RWT_15_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RWT_15_Label.Location = new System.Drawing.Point(28, 499);
            this.RWT_15_Label.Name = "RWT_15_Label";
            this.RWT_15_Label.Size = new System.Drawing.Size(71, 17);
            this.RWT_15_Label.TabIndex = 44;
            this.RWT_15_Label.Text = "RWT[15]";
            this.RWT_15_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // RWT_14_Output
            // 
            this.RWT_14_Output.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.RWT_14_Output.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RWT_14_Output.Location = new System.Drawing.Point(105, 473);
            this.RWT_14_Output.Name = "RWT_14_Output";
            this.RWT_14_Output.Size = new System.Drawing.Size(82, 24);
            this.RWT_14_Output.TabIndex = 43;
            // 
            // RWT_14_Label
            // 
            this.RWT_14_Label.BackColor = System.Drawing.Color.CornflowerBlue;
            this.RWT_14_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RWT_14_Label.Location = new System.Drawing.Point(28, 475);
            this.RWT_14_Label.Name = "RWT_14_Label";
            this.RWT_14_Label.Size = new System.Drawing.Size(71, 17);
            this.RWT_14_Label.TabIndex = 42;
            this.RWT_14_Label.Text = "RWT[14]";
            this.RWT_14_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // RWT_13_Output
            // 
            this.RWT_13_Output.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.RWT_13_Output.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RWT_13_Output.Location = new System.Drawing.Point(105, 448);
            this.RWT_13_Output.Name = "RWT_13_Output";
            this.RWT_13_Output.Size = new System.Drawing.Size(82, 24);
            this.RWT_13_Output.TabIndex = 41;
            // 
            // RWT_13_Label
            // 
            this.RWT_13_Label.BackColor = System.Drawing.Color.CornflowerBlue;
            this.RWT_13_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RWT_13_Label.Location = new System.Drawing.Point(28, 450);
            this.RWT_13_Label.Name = "RWT_13_Label";
            this.RWT_13_Label.Size = new System.Drawing.Size(71, 17);
            this.RWT_13_Label.TabIndex = 40;
            this.RWT_13_Label.Text = "RWT[13]";
            this.RWT_13_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // RWT_12_Output
            // 
            this.RWT_12_Output.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.RWT_12_Output.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RWT_12_Output.Location = new System.Drawing.Point(105, 423);
            this.RWT_12_Output.Name = "RWT_12_Output";
            this.RWT_12_Output.Size = new System.Drawing.Size(82, 24);
            this.RWT_12_Output.TabIndex = 39;
            // 
            // RWT_12_Label
            // 
            this.RWT_12_Label.BackColor = System.Drawing.Color.CornflowerBlue;
            this.RWT_12_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RWT_12_Label.Location = new System.Drawing.Point(28, 424);
            this.RWT_12_Label.Name = "RWT_12_Label";
            this.RWT_12_Label.Size = new System.Drawing.Size(71, 17);
            this.RWT_12_Label.TabIndex = 38;
            this.RWT_12_Label.Text = "RWT[12]";
            this.RWT_12_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // RWT_11_Output
            // 
            this.RWT_11_Output.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.RWT_11_Output.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RWT_11_Output.Location = new System.Drawing.Point(105, 398);
            this.RWT_11_Output.Name = "RWT_11_Output";
            this.RWT_11_Output.Size = new System.Drawing.Size(82, 24);
            this.RWT_11_Output.TabIndex = 37;
            // 
            // RWT_11_Label
            // 
            this.RWT_11_Label.BackColor = System.Drawing.Color.CornflowerBlue;
            this.RWT_11_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RWT_11_Label.Location = new System.Drawing.Point(28, 399);
            this.RWT_11_Label.Name = "RWT_11_Label";
            this.RWT_11_Label.Size = new System.Drawing.Size(71, 17);
            this.RWT_11_Label.TabIndex = 36;
            this.RWT_11_Label.Text = "RWT[11]";
            this.RWT_11_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // RWT_10_Output
            // 
            this.RWT_10_Output.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.RWT_10_Output.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RWT_10_Output.Location = new System.Drawing.Point(105, 373);
            this.RWT_10_Output.Name = "RWT_10_Output";
            this.RWT_10_Output.Size = new System.Drawing.Size(82, 24);
            this.RWT_10_Output.TabIndex = 35;
            // 
            // RWT_10_Label
            // 
            this.RWT_10_Label.BackColor = System.Drawing.Color.CornflowerBlue;
            this.RWT_10_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RWT_10_Label.Location = new System.Drawing.Point(28, 375);
            this.RWT_10_Label.Name = "RWT_10_Label";
            this.RWT_10_Label.Size = new System.Drawing.Size(71, 17);
            this.RWT_10_Label.TabIndex = 34;
            this.RWT_10_Label.Text = "RWT[10]";
            this.RWT_10_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // RWT_9_Output
            // 
            this.RWT_9_Output.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.RWT_9_Output.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RWT_9_Output.Location = new System.Drawing.Point(105, 348);
            this.RWT_9_Output.Name = "RWT_9_Output";
            this.RWT_9_Output.Size = new System.Drawing.Size(82, 24);
            this.RWT_9_Output.TabIndex = 33;
            // 
            // RWT_9_Label
            // 
            this.RWT_9_Label.BackColor = System.Drawing.Color.CornflowerBlue;
            this.RWT_9_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RWT_9_Label.Location = new System.Drawing.Point(28, 350);
            this.RWT_9_Label.Name = "RWT_9_Label";
            this.RWT_9_Label.Size = new System.Drawing.Size(62, 17);
            this.RWT_9_Label.TabIndex = 32;
            this.RWT_9_Label.Text = "RWT[9]";
            this.RWT_9_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(188, 148);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 24);
            this.label1.TabIndex = 48;
            this.label1.Text = "mm";
            // 
            // label2
            // 
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(188, 173);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 24);
            this.label2.TabIndex = 49;
            this.label2.Text = "mm";
            // 
            // label3
            // 
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(188, 198);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 24);
            this.label3.TabIndex = 50;
            this.label3.Text = "mm";
            // 
            // label4
            // 
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(188, 223);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 24);
            this.label4.TabIndex = 51;
            this.label4.Text = "mm";
            // 
            // label5
            // 
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(188, 248);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(34, 24);
            this.label5.TabIndex = 52;
            this.label5.Text = "mm";
            // 
            // label6
            // 
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(188, 273);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(34, 24);
            this.label6.TabIndex = 53;
            this.label6.Text = "mm";
            // 
            // label7
            // 
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(188, 298);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(34, 24);
            this.label7.TabIndex = 54;
            this.label7.Text = "mm";
            // 
            // label8
            // 
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(188, 423);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(34, 24);
            this.label8.TabIndex = 55;
            this.label8.Text = "mm";
            // 
            // label9
            // 
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(188, 398);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(34, 24);
            this.label9.TabIndex = 56;
            this.label9.Text = "mm";
            // 
            // label10
            // 
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(188, 373);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(34, 24);
            this.label10.TabIndex = 57;
            this.label10.Text = "mm";
            // 
            // label11
            // 
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.Location = new System.Drawing.Point(188, 348);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(34, 24);
            this.label11.TabIndex = 58;
            this.label11.Text = "mm";
            // 
            // label12
            // 
            this.label12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.Location = new System.Drawing.Point(188, 323);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(34, 24);
            this.label12.TabIndex = 59;
            this.label12.Text = "mm";
            // 
            // label13
            // 
            this.label13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label13.Location = new System.Drawing.Point(188, 448);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(34, 24);
            this.label13.TabIndex = 60;
            this.label13.Text = "mm";
            // 
            // label14
            // 
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label14.Location = new System.Drawing.Point(188, 473);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(34, 24);
            this.label14.TabIndex = 61;
            this.label14.Text = "mm";
            // 
            // label15
            // 
            this.label15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label15.Location = new System.Drawing.Point(188, 498);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(34, 24);
            this.label15.TabIndex = 62;
            this.label15.Text = "mm";
            // 
            // label16
            // 
            this.label16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label16.Location = new System.Drawing.Point(188, 523);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(34, 24);
            this.label16.TabIndex = 63;
            this.label16.Text = "mm";
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.Color.CornflowerBlue;
            this.label17.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label17.Location = new System.Drawing.Point(22, 102);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(364, 449);
            this.label17.TabIndex = 64;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(871, 670);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.RWT_16_Output);
            this.Controls.Add(this.RWT_16_Label);
            this.Controls.Add(this.RWT_15_Output);
            this.Controls.Add(this.RWT_15_Label);
            this.Controls.Add(this.RWT_14_Output);
            this.Controls.Add(this.RWT_14_Label);
            this.Controls.Add(this.RWT_13_Output);
            this.Controls.Add(this.RWT_13_Label);
            this.Controls.Add(this.RWT_12_Output);
            this.Controls.Add(this.RWT_12_Label);
            this.Controls.Add(this.RWT_11_Output);
            this.Controls.Add(this.RWT_11_Label);
            this.Controls.Add(this.RWT_10_Output);
            this.Controls.Add(this.RWT_10_Label);
            this.Controls.Add(this.RWT_9_Output);
            this.Controls.Add(this.RWT_9_Label);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.RWT_8_Output);
            this.Controls.Add(this.RWT_8_Label);
            this.Controls.Add(this.RWT_7_Output);
            this.Controls.Add(this.RWT_7_Label);
            this.Controls.Add(this.RWT_6_Output);
            this.Controls.Add(this.RWT_6_Label);
            this.Controls.Add(this.RWT_5_Output);
            this.Controls.Add(this.RWT_5_Label);
            this.Controls.Add(this.RWT_4_Output);
            this.Controls.Add(this.RWT_4_Label);
            this.Controls.Add(this.RWT_3_Output);
            this.Controls.Add(this.RWT_3_Label);
            this.Controls.Add(this.RWT_2_Output);
            this.Controls.Add(this.RWT_2_Label);
            this.Controls.Add(this.BarcodeRwtTitle);
            this.Controls.Add(this.RWT_1_Output);
            this.Controls.Add(this.RWT_1_Label);
            this.Controls.Add(this.BarcodeLabel);
            this.Controls.Add(this.BarcodeR);
            this.Controls.Add(this.MainMenuStrip);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.EventLog);
            this.Controls.Add(this.label17);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Geiss CNC Machine Status ( connect via provider PLC)";
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.MainMenuStrip.ResumeLayout(false);
            this.MainMenuStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox EventLog;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel ConnectionLinkLamp;
        private System.Windows.Forms.ToolStripStatusLabel ConnectionStatus;
        private System.Windows.Forms.MenuStrip MainMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pLCToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem connectToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem disconnectToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem connectionSettingsToolStripMenuItem;
        private System.Windows.Forms.Label BarcodeLabel;
        private System.Windows.Forms.TextBox BarcodeR;
        private System.Windows.Forms.Timer Timer1;
        private System.Windows.Forms.Timer Timer2;
        private System.Windows.Forms.Label RWT_1_Label;
        private System.Windows.Forms.TextBox RWT_1_Output;
        private System.Windows.Forms.Label BarcodeRwtTitle;
        private System.Windows.Forms.TextBox RWT_2_Output;
        private System.Windows.Forms.Label RWT_2_Label;
        private System.Windows.Forms.TextBox RWT_3_Output;
        private System.Windows.Forms.Label RWT_3_Label;
        private System.Windows.Forms.TextBox RWT_4_Output;
        private System.Windows.Forms.Label RWT_4_Label;
        private System.Windows.Forms.TextBox RWT_8_Output;
        private System.Windows.Forms.Label RWT_8_Label;
        private System.Windows.Forms.TextBox RWT_7_Output;
        private System.Windows.Forms.Label RWT_7_Label;
        private System.Windows.Forms.TextBox RWT_6_Output;
        private System.Windows.Forms.Label RWT_6_Label;
        private System.Windows.Forms.TextBox RWT_5_Output;
        private System.Windows.Forms.Label RWT_5_Label;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox RWT_16_Output;
        private System.Windows.Forms.Label RWT_16_Label;
        private System.Windows.Forms.TextBox RWT_15_Output;
        private System.Windows.Forms.Label RWT_15_Label;
        private System.Windows.Forms.TextBox RWT_14_Output;
        private System.Windows.Forms.Label RWT_14_Label;
        private System.Windows.Forms.TextBox RWT_13_Output;
        private System.Windows.Forms.Label RWT_13_Label;
        private System.Windows.Forms.TextBox RWT_12_Output;
        private System.Windows.Forms.Label RWT_12_Label;
        private System.Windows.Forms.TextBox RWT_11_Output;
        private System.Windows.Forms.Label RWT_11_Label;
        private System.Windows.Forms.TextBox RWT_10_Output;
        private System.Windows.Forms.Label RWT_10_Label;
        private System.Windows.Forms.TextBox RWT_9_Output;
        private System.Windows.Forms.Label RWT_9_Label;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ToolStripStatusLabel StatusIP_AddressLabel;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem databaseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem watchBarcodeRWTHistoryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem watchMachineParametersHistoryToolStripMenuItem;
    }
}

