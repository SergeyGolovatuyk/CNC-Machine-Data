﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GeissDbConnectedLayer
{
   public class Barcode
    {
       public string CarType { get; set; }
        public string Barcode_LD { get; set; }

        public string Date { get; set; }

        public string Time { get; set; }

        public int FIFO_Number { get; set; }

        public string RWT_1 { get; set; }
        public string RWT_2 { get; set; }
        public string RWT_3 { get; set; }
        public string RWT_4 { get; set; }
        public string RWT_5 { get; set; }
        public string RWT_6 { get; set; }
        public string RWT_7 { get; set; }
        public string RWT_8 { get; set; }
        public string RWT_9 { get; set; }
        public string RWT_10 { get; set; }
        public string RWT_11 { get; set; }
        public string RWT_12 { get; set; }
        public string RWT_13 { get; set; }
        public string RWT_14 { get; set; }
        public string RWT_15 { get; set; }
        public string RWT_16 { get; set; }

    }
}
