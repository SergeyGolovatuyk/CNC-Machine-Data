﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace GeissDbConnectedLayer
{
    public class GeissDB
    {
        #region Properties for reading data from DB with DataSet
        // Properties for reading data from DB with DataSet
        private string carType;
        public string CarType
        {
            get { return carType; }
            set { carType = value; }
        }


        private string date;

        public string Date
        {
            get { return date; }
            set { date = value; }
        }

        // Define global DataTable object
        DataTable dataTable;
        #endregion



        // Creation SQL Connection which will communicate 
        // with all Methods
        private SqlConnection SqlConnection; // connected Layer
        private SqlConnection SqlConnection1; // disconnected Layer

        #region Open Connection to DB

        public void OpenConnection(string ConnectionString)
        {
            SqlConnection = new SqlConnection();
            SqlConnection.ConnectionString = ConnectionString;
            SqlConnection.Open();
        }
        #endregion

        #region Close Connection to DB
        public void CloseConnection()
        {
            SqlConnection.Close();
        }
        #endregion

        #region Insertion Barcode Data to DB
        public void InsertBarcode(Barcode barcode)
        {
            // Creation of a Command string
            string sqlCommand = string.Format("INSERT Into Barcode_RWT" + "(CarType,Barcode,Date,Time,FIFO_Number,RWT_1,RWT_2,RWT_3,RWT_4,RWT_5,RWT_6,RWT_7,RWT_8,RWT_9,RWT_10,RWT_11,RWT_12,RWT_13,RWT_14,RWT_15,RWT_16) Values" +
                "('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}','{13}','{14}','{15}','{16}','{17}','{18}','{19}','{20}')",barcode.CarType, barcode.Barcode_LD, barcode.Date, barcode.Time, barcode.FIFO_Number, barcode.RWT_1, barcode.RWT_2, barcode.RWT_3, barcode.RWT_4, barcode.RWT_5, barcode.RWT_6, barcode.RWT_7, barcode.RWT_8, barcode.RWT_9, barcode.RWT_10, barcode.RWT_11, barcode.RWT_12, barcode.RWT_13, barcode.RWT_14, barcode.RWT_15, barcode.RWT_16);

            // Execution command with SQL Connection
            using(SqlCommand cmd = new SqlCommand(sqlCommand,this.SqlConnection))
            {
                cmd.ExecuteNonQuery();
            }
        }
        #endregion

        #region Insertion RWT Data to DB
        public void InsertRWT(Barcode barcode)
        {
            // Creation of a Command string
            string sqlCommand = string.Format("INSERT Into Barcode_RWT" + "(RWT_1,RWT_2,RWT_3,RWT_4,RWT_5,RWT_6,RWT_7,RWT_8,RWT_9,RWT_10,RWT_11,RWT_12,RWT_13,RWT_14,RWT_15,RWT_16) Values" +
                "('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}','{13}','{14}','{15}')", barcode.RWT_1, barcode.RWT_2, barcode.RWT_3, barcode.RWT_4, barcode.RWT_5, barcode.RWT_6, barcode.RWT_7, barcode.RWT_8, barcode.RWT_9, barcode.RWT_10, barcode.RWT_11, barcode.RWT_12, barcode.RWT_13, barcode.RWT_14, barcode.RWT_15, barcode.RWT_16);

            // Execution command with SQL Connection
            using(SqlCommand cmd = new SqlCommand(sqlCommand,this.SqlConnection))
            {
                cmd.ExecuteNonQuery();
            }
        }
        #endregion

        #region Delete Record from Table
        public void DeleteRecord(int fifo_number)
        {
            // Creation of a Command string
            string sqlCommand = string.Format("DELETE FROM Barcode_RWT WHERE FIFO_Number = {0}", fifo_number);

            //Execution command with SQL Connection
            using(SqlCommand cmd = new SqlCommand(sqlCommand,this.SqlConnection))
            {
                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch(SqlException exc)
                {
                    Exception error = new Exception("Part with this count number\n not found in DB", exc);
                    throw exc;
                }

            }


        }
        #endregion

        #region Select Record from DB
        public void SelectRecordFifo(int fifo_number)
        {
            // Creation of a Command string
            string sqlCommand = string.Format("SELECT * FROM Barcode_RWT WHERE FIFO_Number = '{0}'", fifo_number);

            // Execution command with SQL Connection
            using(SqlCommand cmd = new SqlCommand(sqlCommand,this.SqlConnection))
            {
                try
                {
                    cmd.ExecuteReader();
                }
                catch(Exception exc)
                {
                    Exception error = new Exception("Part with this count number\n not found in DB", exc);
                    throw exc;
                }
            }
        }

        public void SelectRecordCarType_Date(string cartype, string date)
        {
            // Creation of command string
            string sqlCommand = string.Format("SELECT * FROM Barcode_RWT WHERE CarType = {0} and Date  = {1}", cartype,date);

            using(SqlCommand cmd = new SqlCommand(sqlCommand,SqlConnection))
            {
                try
                {
                    cmd.ExecuteReader();
                }
                catch(Exception ex)
                {
                    Exception error = new Exception("Part of this Type and Date\n not found in DB", ex);
                }
            }
        }

        
        #endregion

        public DataSet GetDBDataAsDataSet()
        {
            // Creation DataSet object of Geiss DB

            DataSet barcodeRwtDS = new DataSet("BarcodeRWT_DataSet");
            barcodeRwtDS.ExtendedProperties["TimeStamp"] = DateTime.Now;
            barcodeRwtDS.ExtendedProperties["DataSetID"] = Guid.NewGuid();
            barcodeRwtDS.ExtendedProperties["Company"] = "Huyndai Mobis RUS";

            return barcodeRwtDS;
        }

        public DataTable FillDataSet(DataSet ds, string cartype, string date, string connectionString)
        {

            // Create columns of data
            // **********************************
            DataColumn CarTypeColumn = new DataColumn("CarType", typeof(string));
            CarTypeColumn.ReadOnly = true;
            // **********************************
            DataColumn BarcodeColumn = new DataColumn("BarCode", typeof(string));
            BarcodeColumn.Caption = "Barcode";
            BarcodeColumn.AllowDBNull = false;
            BarcodeColumn.ReadOnly = true;
            BarcodeColumn.Unique = true;
            // **********************************
            DataColumn DateColumn = new DataColumn("Date",typeof(string));
            DateColumn.ReadOnly = true;
            // **********************************
            DataColumn TimeColumn = new DataColumn("Time",typeof(string));
            TimeColumn.ReadOnly = true;
            // **********************************
            DataColumn FifoColumn = new DataColumn("FIFO_Number",typeof(int));
            FifoColumn.ReadOnly = true;
            // **********************************
            DataColumn Rwt1_Column = new DataColumn("RWT_1",typeof(string));
            Rwt1_Column.ReadOnly = true;
            // **********************************
            DataColumn Rwt2_Column = new DataColumn("RWT_2",typeof(string));
            Rwt2_Column.ReadOnly = true;
            // **********************************
            DataColumn Rwt3_Column = new DataColumn("RWT_3",typeof(string));
            Rwt3_Column.ReadOnly = true;
            // **********************************
            DataColumn Rwt4_Column = new DataColumn("RWT_4",typeof(string));
            Rwt4_Column.ReadOnly = true;
            // **********************************
            DataColumn Rwt5_Column = new DataColumn("RWT_5",typeof(string));
            // **********************************
            DataColumn Rwt6_Column = new DataColumn("RWT_6",typeof(string));
            // **********************************
            DataColumn Rwt7_Column = new DataColumn("RWT_7",typeof(string));
            // **********************************
            DataColumn Rwt8_Column = new DataColumn("RWT_8",typeof(string));
            // **********************************
            DataColumn Rwt9_Column = new DataColumn("RWT_9",typeof(string));
            // **********************************
            DataColumn Rwt10_Column = new DataColumn("RWT_10",typeof(string));
            // **********************************
            DataColumn Rwt11_Column = new DataColumn("RWT_11",typeof(string));
            // **********************************
            DataColumn Rwt12_Column = new DataColumn("RWT_12",typeof(string));
            // **********************************
            DataColumn Rwt13_Column = new DataColumn("RWT_13",typeof(string));
            // **********************************
            DataColumn Rwt14_Column = new DataColumn("RWT_14",typeof(string));
            // **********************************
            DataColumn Rwt15_Column = new DataColumn("RWT_15",typeof(string));
            // **********************************
            DataColumn Rwt16_Column = new DataColumn("RWT_16",typeof(string));

            // Create DataTable object containing DataColumn objects

            DataTable BarcodeRwtDataTable = new DataTable("GeissDbTable");
            
            BarcodeRwtDataTable.Columns.AddRange(new DataColumn[] 
                {CarTypeColumn,BarcodeColumn,DateColumn,TimeColumn,FifoColumn,Rwt1_Column,Rwt2_Column,
                Rwt3_Column,Rwt4_Column,Rwt5_Column,Rwt6_Column,Rwt7_Column,Rwt8_Column,Rwt9_Column,
                Rwt10_Column,Rwt11_Column,Rwt12_Column,Rwt13_Column,Rwt14_Column,Rwt15_Column,Rwt16_Column});

           /* if (this.SqlConnection.State == ConnectionState.Closed)
                this.SqlConnection.Open();*/

            SqlConnection1 = new System.Data.SqlClient.SqlConnection();
            SqlConnection1.ConnectionString = connectionString;
            SqlConnection1.Open();                        
            SqlTransaction transact = SqlConnection1.BeginTransaction(); // Start transaction from DB if connection is opened
            SqlDataAdapter dataAdapter = new SqlDataAdapter();
            string sqlQuery = string.Format("SELECT * FROM Barcode_RWT WHERE CarType = '{0}' and Date = '{1}'", cartype, date);
            SqlCommand cmd = new SqlCommand(sqlQuery, SqlConnection1);
            cmd.Transaction = transact;

            try
            {
                cmd.CommandType = CommandType.Text;
                SqlDataReader dataReader = cmd.ExecuteReader();
                BarcodeRwtDataTable.Load(dataReader);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occured while read from DB!: " + ex.Message, "", MessageBoxButtons.OK);
            }
            cmd.Dispose();
            SqlConnection1.Close();
            return BarcodeRwtDataTable;



        }

     /*   public DataTable selection(string sqlQuery)
        {
            if (SqlConnection.State == ConnectionState.Closed)
                SqlConnection.Open();

            SqlTransaction transact = SqlConnection.BeginTransaction(); // Start transaction from DB if connection is opened
            DataTable dt = new DataTable(); // Create new DataTable instance
            SqlDataAdapter dataAdapter = new SqlDataAdapter();
            SqlCommand cmd = new SqlCommand(sqlQuery, SqlConnection);
            cmd.Transaction = transact;

            try
            {
                cmd.CommandType = CommandType.Text;
                SqlDataReader dataReader = cmd.ExecuteReader();
                dt.Load(dataReader);
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error occured while read from DB!: " + ex.Message, "", MessageBoxButtons.OK);
            }
            cmd.Dispose();
            dataTable = dt;

            return dt;

        } */



    }
}
