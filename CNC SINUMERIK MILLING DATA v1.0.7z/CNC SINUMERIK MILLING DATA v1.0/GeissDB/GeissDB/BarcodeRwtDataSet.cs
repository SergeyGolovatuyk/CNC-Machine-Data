﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace GeissDbConnectedLayer
{
    public class BarcodeRwtDataSet
    {

      /*  private string carType;

        public string CarType
        {
            get { return carType; }
            set { carType = value; }
        }


        private string date;

        public string Date
        {
            get { return date; }
            set { date = value; }
        }


        public BarcodeRwtDataSet(string carType, string date)
        {
            carType = this.carType;
            date = this.date;
        }


        public void GetDBDataAsDataSet()
        {
            // Creation DataSet object of Geiss DB

            DataSet barcodeRwtDS = new DataSet("BarcodeRWT_DataSet");
            barcodeRwtDS.ExtendedProperties["TimeStamp"] = DateTime.Now;
            barcodeRwtDS.ExtendedProperties["DataSetID"] = Guid.NewGuid();
            barcodeRwtDS.ExtendedProperties["Company"] = "Huyndai Mobis RUS";
        }

        static void FillDataSet(DataSet ds)
        {

            // Create columns of data
            // **********************************
            DataColumn CarTypeColumn = new DataColumn("CarType", typeof(string));
            CarTypeColumn.ReadOnly = true;
            // **********************************
            DataColumn BarcodeColumn = new DataColumn("BarCode", typeof(string));
            BarcodeColumn.Caption = "Barcode";
            BarcodeColumn.AllowDBNull = false;
            BarcodeColumn.ReadOnly = true;
            BarcodeColumn.Unique = true;
            // **********************************
            DataColumn DateColumn = new DataColumn("Date",typeof(string));
            DateColumn.ReadOnly = true;
            // **********************************
            DataColumn TimeColumn = new DataColumn("Time",typeof(string));
            TimeColumn.ReadOnly = true;
            // **********************************
            DataColumn FifoColumn = new DataColumn("FIFO",typeof(int));
            FifoColumn.ReadOnly = true;
            // **********************************
            DataColumn Rwt1_Column = new DataColumn("RWT_1",typeof(string));
            Rwt1_Column.ReadOnly = true;
            // **********************************
            DataColumn Rwt2_Column = new DataColumn("RWT_2",typeof(string));
            Rwt2_Column.ReadOnly = true;
            // **********************************
            DataColumn Rwt3_Column = new DataColumn("RWT_3",typeof(string));
            Rwt3_Column.ReadOnly = true;
            // **********************************
            DataColumn Rwt4_Column = new DataColumn("RWT_4",typeof(string));
            Rwt4_Column.ReadOnly = true;
            // **********************************
            DataColumn Rwt5_Column = new DataColumn("RWT_5",typeof(string));
            // **********************************
            DataColumn Rwt6_Column = new DataColumn("RWT_6",typeof(string));
            // **********************************
            DataColumn Rwt7_Column = new DataColumn("RWT_7",typeof(string));
            // **********************************
            DataColumn Rwt8_Column = new DataColumn("RWT_8",typeof(string));
            // **********************************
            DataColumn Rwt9_Column = new DataColumn("RWT_9",typeof(string));
            // **********************************
            DataColumn Rwt10_Column = new DataColumn("RWT_10",typeof(string));
            // **********************************
            DataColumn Rwt11_Column = new DataColumn("RWT_11",typeof(string));
            // **********************************
            DataColumn Rwt12_Column = new DataColumn("RWT_12",typeof(string));
            // **********************************
            DataColumn Rwt13_Column = new DataColumn("RWT_13",typeof(string));
            // **********************************
            DataColumn Rwt14_Column = new DataColumn("RWT_14",typeof(string));
            // **********************************
            DataColumn Rwt15_Column = new DataColumn("RWT_15",typeof(string));
            // **********************************
            DataColumn Rwt16_Column = new DataColumn("RWT_16",typeof(string));

            // Create DataTable object containing DataColumn objects

            DataTable BarcodeRwtDataTable = new DataTable("GeissDbTable");
          BarcodeRwtDataTable.Columns.AddRange(new DataColumn[] 
                {CarTypeColumn,BarcodeColumn,DateColumn,TimeColumn,FifoColumn,Rwt1_Column,Rwt2_Column,
                Rwt3_Column,Rwt4_Column,Rwt5_Column,Rwt6_Column,Rwt7_Column,Rwt8_Column,Rwt9_Column,
                Rwt10_Column,Rwt11_Column,Rwt12_Column,Rwt13_Column,Rwt14_Column,Rwt15_Column,Rwt16_Column});*/

            
        }


    }
